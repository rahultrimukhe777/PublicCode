import { ClientMode } from "./ClientMode";
import { WebPartContext } from "@microsoft/sp-webpart-base"; 
export interface IRclGraphAuthProps {
  description: string;
  isDarkTheme: boolean;
  environmentMessage: string;
  hasTeamsContext: boolean;
  userDisplayName: string;
  clientMode: ClientMode;
  context: WebPartContext;
}
