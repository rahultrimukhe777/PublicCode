/* tslint:disable */
require("./RclGraphAuth.module.css");
const styles = {
  form: 'form_1b0f101a',
  rclGraphAuth: 'rclGraphAuth_1b0f101a',
  teams: 'teams_1b0f101a',
  welcome: 'welcome_1b0f101a',
  welcomeImage: 'welcomeImage_1b0f101a',
  links: 'links_1b0f101a'
};

export default styles;
/* tslint:enable */