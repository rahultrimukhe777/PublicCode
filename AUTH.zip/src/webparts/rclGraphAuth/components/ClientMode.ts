export enum ClientMode {
  aad,
  graph,
}