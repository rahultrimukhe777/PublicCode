export interface IUserItem {
    displayName: string;
    mail: string;
    userPrincipalName: string;
}
//# sourceMappingURL=IUserItem.d.ts.map