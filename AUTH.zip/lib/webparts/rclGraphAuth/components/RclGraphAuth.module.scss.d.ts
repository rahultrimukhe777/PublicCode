declare const styles: {
    form: string;
    rclGraphAuth: string;
    teams: string;
    welcome: string;
    welcomeImage: string;
    links: string;
};
export default styles;
//# sourceMappingURL=RclGraphAuth.module.scss.d.ts.map