export declare enum ClientMode {
    aad = 0,
    graph = 1
}
//# sourceMappingURL=ClientMode.d.ts.map