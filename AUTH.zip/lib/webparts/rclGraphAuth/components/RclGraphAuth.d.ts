import * as React from 'react';
import { IRclGraphAuthProps } from './IRclGraphAuthProps';
import { IGraphConsumerState } from "./IGraphConsumerState";
export default class RclGraphAuth extends React.Component<IRclGraphAuthProps, IGraphConsumerState> {
    constructor(props: IRclGraphAuthProps, state: IGraphConsumerState);
    private _onSearchForChanged;
    private _getSearchForErrorMessage;
    private _search;
    private _searchWithAad;
    private _searchWithGraph;
    render(): React.ReactElement<IRclGraphAuthProps>;
}
//# sourceMappingURL=RclGraphAuth.d.ts.map